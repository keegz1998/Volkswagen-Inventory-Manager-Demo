<!DOCTYPE html>
<html lang="en">
<head>
    <title>VW Makes</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/style.css') }}">
</head>
<body>
    <x-nav />
    <div class="container">
        <div class="table">
            <div class="table-header">
                <div class="header__item"><a id="name" class="filter__link" href="#">Car Make:</a></div>
                <div class="header__item"><a id="draws" class="filter__link filter__link--number" href="#">Stock available:</a></div>
            </div>
            <div class="table-content">
                @foreach($makes as $make)
                <div class="table-row">
                    <div class="table-data">{{$make->MakeName}}</div>
                    <div class="table-data">{{$make->MakeStock}}</div>
                </div>
                @endforeach
            </div>
        </div>
    </div>
    <x-footer />
</body>
</html>