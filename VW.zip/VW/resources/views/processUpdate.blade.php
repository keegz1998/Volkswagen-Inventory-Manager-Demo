<?php
$model_name =$_POST['Model_name'];
$price =  $_POST['price'];
$stock =  $_POST['stock'];
$makeID = $_POST['make'];
$arr_length = count($models);
for($i =0; $i < $arr_length;$i++){
    if($models[$i]-> ModelName === $model_name){
        $model_ID = $models[$i]->ModelID;
        header("Location: http://localhost:8000/edit/".$model_ID."/".$price."/".$stock."/".$makeID);
        exit();
    }
}

?>