<!DOCTYPE html>
<html lang="en">
<head>
    <title>Models Table</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/style.css') }}">
</head>
<body>
    <x-nav />
    <div class="container">
        <div class="table">
            <div class="table-header">
                <div class="header__item"><a id="name" class="filter__link" href="#">Car Make:</a></div>
                <div class="header__item"><a id="wins" class="filter__link filter__link--number" href="#">Price:</a></div>
                <div class="header__item"><a id="draws" class="filter__link filter__link--number" href="#">Stock available:</a></div>
                <div class="header__item"><a id="draws" class="filter__link filter__link--number" href="#">Car Model:</a></div>
                <div class="header__item"><a id="draws" class="filter__link filter__link--number" href="#"></a></div>
            </div>
            <div class="table-content">
                <?php
                $models_arr_length = count($arr[0]);
                $makes_arr_length = count($arr[1]);
                ?>
                @for($i = 0; $i < $models_arr_length; $i++) <div class="table-row">
                    <div class="table-data">{{$arr[0][$i]->ModelName}}</div>
                    <div class="table-data">R{{$arr[0][$i]->Price}}</div>
                    <div class="table-data">{{$arr[0][$i]->ModelStock}}</div>
                    <?php
                    switch ($arr[0][$i]->MakeID) {
                        case 1:
                            $modelName = "Polo";
                            break;
                        case 2:
                            $modelName = "Tiguan";
                            break;
                        case 3:
                            $modelName = "Caddy";
                                break;
                    }
                    ?> 
                    <div class="table-data">{{$modelName}}</div>
                    <div class="table-data"><a href="/model/{{$arr[0][$i]->ModelID}}" class="button">View Model</a></div>
            </div>
            @endfor
        </div>
    </div>
    </div>
</body>
<x-footer/>
</html>