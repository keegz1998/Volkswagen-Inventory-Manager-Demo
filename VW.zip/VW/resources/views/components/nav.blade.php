<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<div class="topnav" id="myTopnav">
  <a href="/" class="active">Home</a>
  <a href="/models">Models</a>
  <a href="/makes">Makes</a>
  <a href="/create">Create Model</a>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>
<script src="{{ asset('JS/home.js') }}"></script>