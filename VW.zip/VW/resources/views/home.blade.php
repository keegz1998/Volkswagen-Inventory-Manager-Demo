<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Volkswagen | Inventory</title>
</head>
<body>
  <!-- Load an icon library to show a hamburger menu (bars) on small screens -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="{{ asset('css/home.css') }}">
  <x-nav />
  <form class="example" action="/processSearch.blade.php" method="POST" style="margin:auto;max-width:600px">
    <div class="searchDisp">
      <img id="vw-logo" src="https://cdn.mos.cms.futurecdn.net/7k4pmuhoKvdyaL2Ams4Nmd-970-80.png.webp" alt="">
      <h1>Volkswagen</h1>
    </div>
    @csrf
    <input type="text" id="Model_name" name="Model_name" placeholder="Model name...">
    <button type="submit" value="submit"><i class="fa fa-search"></i></button>
    <div class="searchDisp2">
      <a href="/models" class="button">View Models</a>
      <a href="/makes" class="button">View Makes</a>
      <a href="/create" class="button">Create Model</a>
    </div>
  </form>
  <x-footer />
</body>
<script src="{{ asset('JS/home.js') }}"></script>
</html>