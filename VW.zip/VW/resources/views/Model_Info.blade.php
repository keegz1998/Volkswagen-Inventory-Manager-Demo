<html>
<head>
<title>Model Details</title>
<link rel="stylesheet" type="text/css" href="{{ asset('css/style.css') }}">
</head>
<body>
<x-nav/>
<?php
    $car_features_length =count($arr[1]);
    $feature_list_length = count($arr[2]);
    $makes_length = count($arr[3]);
    ?>
    @for($y = 0; $y < $makes_length; $y++)
    <?php
    if($arr[3][$y]->MakeID === $arr[0]->MakeID){
        $MakeName = $arr[3][$y]->MakeName;
    }
    $model_id = $arr[0]->ModelID;
    $make_id = $arr[0]-> MakeID;
    $Stock = $arr[0]->ModelStock;
    $Price = $arr[0]->Price;
    $modelName = $arr[0]->ModelName;
    $update_link="/update/". $model_id;
    $delete_link="/delete/". $model_id."/".$Stock."/".$make_id;
    $edit_link="/update/". $modelName."/".$Stock."/".$Price;
    ?>
    @endfor
<div class="infoDiv">
<h1>{{$MakeName}} {{$arr[0]->ModelName}}</h1>
<h2>Car Details:</h2>
    <div class="grid-container">
  
  <div class="grid-item"><b>ModelID:</b> {{$arr[0]->ModelID}}</div>
  <div class="grid-item"><b>Model Name:</b> {{$arr[0]->ModelName}}</div>
  <div class="grid-item"><b>Price:R</b> {{$arr[0]->Price}}.00</div>  
  <div class="grid-item"><b>Stock Available:</b> {{$arr[0]->ModelStock}}</div>
  </div>
  <h2>Car Features:</h2>    
    <ul>
    @for($x = 0;$x < $car_features_length; $x++)
        @for($i=0; $i < $feature_list_length; $i++)
            <?php
            if($arr[1][$x]->FeatureID === $arr[2][$i]->FeatureID)
            $feature = $arr[2][$i]->FeatDesc;
            ?>            
            @endfor
            <li>{{$feature}}</li>
    @endfor
    </ul>   
  <div  class="btnDiv">
  <a href="{{$update_link}}"class="button"> Decrease Stock</a>
    <a href="{{$delete_link}}"class="button"> Delete Model</a>
    <a href="{{$edit_link}}"class="button"> Edit Model</a>      
  </div>    
    </div>
    <x-footer/>
</body>
</html>