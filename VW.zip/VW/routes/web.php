<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//home route
Route::get('/', function () {
    return view('test');
});
// Route to display all Car Makes
Route::get('/models', function () {
    $models = DB::table('Car_Models')->get();
    $makes = DB::table('Car_Make')->get();
    $arr = [$models, $makes];
    return view('Models', ['arr' => $arr]);
});
// Route to display all Car Models
Route::get('/makes', function () {
    $makes = DB::table('Car_Make')->get();
    return view('Makes', ['makes' => $makes]);
});
// Route that lists a car with a specific ID
Route::get('/model/{ModelID}', function ($ModelID) {
    $cars = DB::table('Car_Models')->where('ModelID', "=", $ModelID)->first();
    $model_features = DB::table('Car_Features')->where('ModelID', "=", $ModelID)->get();
    $features_list = DB::table('Feature_Description')->get();
    $makes = DB::table('Car_Make')->get();
    $arr = [$cars, $model_features, $features_list, $makes];
    return view('Model_Info', ['arr' => $arr]);
});
// Route to decrement a cars stock
Route::get('/update/{ModelID}', function ($ModelID) {
    DB::table('Car_Models')->where('ModelID', "=", $ModelID)->decrement('ModelStock', 1);
    $cars = DB::table('Car_Models')->where('ModelID', "=", $ModelID)->first();
    $make_ID = $cars->MakeID;
    DB::table('Car_Make')->where('MakeID', "=", $make_ID)->decrement('MakeStock', 1);
    $model_features = DB::table('Car_Features')->where('ModelID', "=", $ModelID)->get();
    $features_list = DB::table('Feature_Description')->get();
    $makes = DB::table('Car_Make')->get();
    $arr = [$cars, $model_features, $features_list, $makes];
    return view('Model_Info', ['arr' => $arr]);
});
// Route to populate edit fields
Route::get('/update/{ModelName}/{Price}/{Stock}', function ($ModelName, $Price, $Stock) {
    $arr = [$ModelName, $Price, $Stock];
    return view('update', ['arr' => $arr]);
});
// Route to update model
Route::get('/edit/{ModelID}/{Price}/{Stock}/{MakeID}', function ($ModelID, $Price, $Stock, $MakeID) {
    DB::table('Car_Models')
        ->where('ModelID', "=", $ModelID)
        ->update(['ModelStock' => $Stock, 'Price' => $Price, 'MakeID' => $MakeID]);
        DB::table('Car_Make')->where('MakeID', "=", $MakeID)->increment('MakeStock', $Stock);
    return view('home');
});
// route to process update
Route::post('processUpdate.blade.php', function () {
    $models = DB::table('Car_Models')->get();
    return view('processUpdate', ['models' => $models]);
});
// Route to delete a car model
Route::get('/delete/{ModelID}/{Stock}/{MakeID}', function ($ModelID, $Stock, $make_ID) {
    DB::table('Car_Models')
        ->where('ModelID', "=", $ModelID)
        ->delete();
    DB::table('Car_Make')->where('MakeID', "=", $make_ID)->decrement('MakeStock', $Stock);
    return redirect()->to('http://localhost:8000/models');
});
Route::get('/create', function () {
    return view('create');
});
Route::post('/processCreate.blade.php', function () {
    $models = DB::table('Car_Models')->get();
    return view('processCreate', ['models' => $models]);
});
Route::get('/create/{ModelID}/{ModelName}/{Price}/{Stock}/{MakeID}', function ($ModelID, $ModelName, $Price, $Stock, $make_ID) {
    DB::table('Car_Models')->insert([
        'ModelID' => $ModelID,
        'ModelName' => $ModelName,
        'Price' => $Price,
        'ModelStock' => $Stock,
        'MakeID' => $make_ID
    ]);
    DB::table('Car_Make')->where('MakeID', "=", $make_ID)->increment('MakeStock', $Stock);
    return view('home');
});
Route::get('/', function () {
    return view('home');
});
Route::get('/search_fail', function () {
    return view('SearchFail');
});
Route::post('/processSearch.blade.php', function () {
    $models = DB::table('Car_Models')->get();
    return view('processSearch', ['models' => $models]);
});
  


