<!DOCTYPE html>
<html lang="en">
<head>
    <title>Models Table</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav','data' => []]); ?>
<?php $component->withName('nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <div class="container">
        <div class="table">
            <div class="table-header">
                <div class="header__item"><a id="name" class="filter__link" href="#">Car Make:</a></div>
                <div class="header__item"><a id="wins" class="filter__link filter__link--number" href="#">Price:</a></div>
                <div class="header__item"><a id="draws" class="filter__link filter__link--number" href="#">Stock available:</a></div>
                <div class="header__item"><a id="draws" class="filter__link filter__link--number" href="#">Car Model:</a></div>
                <div class="header__item"><a id="draws" class="filter__link filter__link--number" href="#"></a></div>
            </div>
            <div class="table-content">
                <?php
                $models_arr_length = count($arr[0]);
                $makes_arr_length = count($arr[1]);
                ?>
                <?php for($i = 0; $i < $models_arr_length; $i++): ?> <div class="table-row">
                    <div class="table-data"><?php echo e($arr[0][$i]->ModelName); ?></div>
                    <div class="table-data">R<?php echo e($arr[0][$i]->Price); ?></div>
                    <div class="table-data"><?php echo e($arr[0][$i]->ModelStock); ?></div>
                    <?php
                    switch ($arr[0][$i]->MakeID) {
                        case 1:
                            $modelName = "Polo";
                            break;
                        case 2:
                            $modelName = "Tiguan";
                            break;
                        case 3:
                            $modelName = "Caddy";
                                break;
                    }
                    ?> 
                    <div class="table-data"><?php echo e($modelName); ?></div>
                    <div class="table-data"><a href="/model/<?php echo e($arr[0][$i]->ModelID); ?>" class="button">View Model</a></div>
            </div>
            <?php endfor; ?>
        </div>
    </div>
    </div>
</body>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.footer','data' => []]); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
</html><?php /**PATH C:\Users\keega\newsclip\resources\views/Models.blade.php ENDPATH**/ ?>