<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <!-- Load an icon library to show a hamburger menu (bars) on small screens -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/home.css')); ?>">

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav','data' => []]); ?>
<?php $component->withName('nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<form class="example"action="/processSearch.blade.php" method="POST" style="margin:auto;max-width:600px">
<div class="searchDisp">

<img id="vw-logo"src="https://cdn.mos.cms.futurecdn.net/7k4pmuhoKvdyaL2Ams4Nmd-970-80.png.webp" alt="">
<h1>Volkswagen</h1>
</div>

  <?php echo csrf_field(); ?>
  <input type="text" id="Model_name" name="Model_name" placeholder="Model name...">
  
  
<button type="submit" value="submit"><i class="fa fa-search"></i></button>

 <div class="searchDisp2">
 <p>No model of car matches your search. Please try again.</p>
<a href="/models" class="button">View Models</a>
<a href="/makes" class="button">View Makes</a>
<a href="/create" class="button">Create Model</a>
</div>
</form>


<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.footer','data' => []]); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

</body>
<script src="<?php echo e(asset('JS/home.js')); ?>"></script>
</html><?php /**PATH C:\Users\keega\newsclip\resources\views/SearchFail.blade.php ENDPATH**/ ?>