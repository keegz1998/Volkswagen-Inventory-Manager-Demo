<html>
<head>
<title>Model Details</title>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav','data' => []]); ?>
<?php $component->withName('nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php
    $car_features_length =count($arr[1]);
    $feature_list_length = count($arr[2]);
    $makes_length = count($arr[3]);
    ?>
    <?php for($y = 0; $y < $makes_length; $y++): ?>
    <?php
    if($arr[3][$y]->MakeID === $arr[0]->MakeID){
        $MakeName = $arr[3][$y]->MakeName;
    }
    $model_id = $arr[0]->ModelID;
    $make_id = $arr[0]-> MakeID;
    $Stock = $arr[0]->ModelStock;
    $Price = $arr[0]->Price;
    $modelName = $arr[0]->ModelName;
    $update_link="/update/". $model_id;
    $delete_link="/delete/". $model_id."/".$Stock."/".$make_id;
    $edit_link="/update/". $modelName."/".$Stock."/".$Price;
    ?>
    <?php endfor; ?>
<div class="infoDiv">
<h1><?php echo e($MakeName); ?> <?php echo e($arr[0]->ModelName); ?></h1>
<h2>Car Details:</h2>
    <div class="grid-container">
  
  <div class="grid-item"><b>ModelID:</b> <?php echo e($arr[0]->ModelID); ?></div>
  <div class="grid-item"><b>Model Name:</b> <?php echo e($arr[0]->ModelName); ?></div>
  <div class="grid-item"><b>Price:R</b> <?php echo e($arr[0]->Price); ?>.00</div>  
  <div class="grid-item"><b>Stock Available:</b> <?php echo e($arr[0]->ModelStock); ?></div>
  </div>
  <h2>Car Features:</h2>    
    <ul>
    <?php for($x = 0;$x < $car_features_length; $x++): ?>
        <?php for($i=0; $i < $feature_list_length; $i++): ?>
            <?php
            if($arr[1][$x]->FeatureID === $arr[2][$i]->FeatureID)
            $feature = $arr[2][$i]->FeatDesc;
            ?>            
            <?php endfor; ?>
            <li><?php echo e($feature); ?></li>
    <?php endfor; ?>
    </ul>   
  <div  class="btnDiv">
  <a href="<?php echo e($update_link); ?>"class="button"> Decrease Stock</a>
    <a href="<?php echo e($delete_link); ?>"class="button"> Delete Model</a>
    <a href="<?php echo e($edit_link); ?>"class="button"> Edit Model</a>      
  </div>    
    </div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.footer','data' => []]); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
</body>
</html><?php /**PATH C:\Users\keega\newsclip\resources\views/Model_Info.blade.php ENDPATH**/ ?>