<?php
$model_name =$_POST['Model_name'];
$arr_length = count($models);
for ($i =0; $i < $arr_length;$i++) {
    if ($models[$i]-> ModelName === $model_name) {
        $model_ID = $models[$i]->ModelID;
        header("Location: http://localhost:8000/model/".$model_ID);
        exit();
    }
}header("Location: http://localhost:8000/search_fail");
exit();
?><?php /**PATH C:\Users\keega\newsclip\resources\views/processSearch.blade.php ENDPATH**/ ?>