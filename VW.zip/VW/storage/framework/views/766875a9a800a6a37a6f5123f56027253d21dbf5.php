<html>
<head>
<title>Cool Blog Homepage</title>
</head>
<body>
<h1>Welcome to the homepage of my cool blog!</h1>
<a href="<?php echo e(url('/about')); ?>">About</a>
<p>Today is <?php echo e(date('j F Y')); ?>.</p>
<h2>Blog posts:</h2>
<?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p>Car Make:<?php echo e($car->ModelName); ?></p>
<p>Price: R<?php echo e($car->Price); ?></p>
<p>Stock available: <?php echo e($car->ModelStock); ?></p>







<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html><?php /**PATH C:\Users\keega\newsclip\resources\views/test.blade.php ENDPATH**/ ?>