<html>
<head>
<title>Cool Blog Homepage</title>
</head>
<body>
<h1>Welcome to the homepage of my cool blog!</h1>
<a href="<?php echo e(url('/about')); ?>">About</a>
<p>Today is <?php echo e(date('j F Y')); ?>.</p>
<h2>Blog posts:</h2>
<?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p>Car Make:<?php echo e($model->ModelName); ?></p>
<p>Stock available: <?php echo e($model->ModelStock); ?></p>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html><?php /**PATH C:\Users\keega\newsclip\resources\views/models.blade.php ENDPATH**/ ?>