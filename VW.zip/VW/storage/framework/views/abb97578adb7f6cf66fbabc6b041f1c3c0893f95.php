<div class="footer">
  <p>Volkswagen &copy 1970 - 2021</p>
</div><?php /**PATH C:\Users\keega\newsclip\resources\views/components/footer.blade.php ENDPATH**/ ?>