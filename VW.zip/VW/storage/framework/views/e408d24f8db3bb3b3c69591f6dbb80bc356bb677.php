<?php
$model_name =$_POST['Model_name'];
$price =  $_POST['price'];
$stock =  $_POST['stock'];
$make_id =$_POST['car_make'];
$arr_length = count($models);
$model_id = $arr_length+1 ;
        header("Location: http://localhost:8000/create/".$model_id."/".$model_name."/".$price."/".$stock."/".$make_id);
        exit();
?><?php /**PATH C:\Users\keega\newsclip\resources\views/processCreate.blade.php ENDPATH**/ ?>