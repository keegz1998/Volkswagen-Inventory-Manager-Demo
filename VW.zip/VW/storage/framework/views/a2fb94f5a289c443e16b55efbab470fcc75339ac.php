<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/update.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/home.css')); ?>">
</head>
<body>
  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav','data' => []]); ?>
<?php $component->withName('nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
  <div class="container">
    <h1 id="title">Car Model Details:</h1>
    <form action="processCreate.blade.php" method="POST">
      <?php echo csrf_field(); ?>
      <div class="row">
        <div class="col-25">
          <label for="Model_name">Model Name:</label>
        </div>
        <div class="col-75">
          <input type="text" id="Model_name" name="Model_name" placeholder="Model name...">
        </div>
      </div>
      <div class="row">
        <div class="col-25">
          <label for="price">Price:</label>
        </div>
        <div class="col-75">
          <input type="number" id="price" name="price" placeholder="Price of Model...">
        </div>
      </div>
      <div class="row">
        <div class="col-25">
          <label for="stock">Stock:</label>
        </div>
        <div class="col-75">
          <input type="number" id="stock" name="stock" placeholder="Amount of Stock remaining...">
        </div>
      </div>
      <div class="row">
        <div class="col-25">
          <label for="car_make">Make:</label>
        </div>
        <div class="col-75">
          <select id="car_make" name="car_make">
            <option value="1">Polo</option>
            <option value="2">Tiguan</option>
            <option value="3">Caddy</option>
          </select>
        </div>
      </div>
      <div class="row">
        <input type="submit" value="Submit">
      </div>
    </form>
  </div>
  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.footer','data' => []]); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
</body>
</html>
<!--Submit all data to a php file, then take the data and redirect to a url--><?php /**PATH C:\Users\keega\newsclip\resources\views/create.blade.php ENDPATH**/ ?>